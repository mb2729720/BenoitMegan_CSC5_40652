/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 9, 2018, 11:12 PM
 * Purpose:  Lab 1/10/18
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float gasPrice = 3.98; //assuming gas costs $3.98/gal
    float oilProfitMin = 0.07, oilProfitMax = 0.065*gasPrice; //oil profit ranges from $0.07/gal to 6.5% of gas price
    float fedTax = 0.184, stateTax = 0.417, stateSalesTax = 0.0225*gasPrice; //federal tax is $0.184/gal, state tax is $0.417/gal, state sales tax is 2.25% of gas price
    float totalTax = fedTax+stateTax+stateSalesTax; //total tax is federal+state+state sales
    float percentTax = totalTax/gasPrice; //percent tax is total tax/gas price
    float oilProfitRange = oilProfitMax-oilProfitMin; //oil company profit range is difference between maximum and minimum
    cout<<"1) The total tax on a gallon of gas   = $"<<totalTax<<endl;
    cout<<"2) The base price for a gallon of gas = $"<<gasPrice<<endl;
    cout<<"3) Percentage price due to gas tax    = "<<percentTax<<"%"<<endl;
    cout<<"4) Oil Company profit range           = "<<oilProfitRange<<"%"<<endl;
    
    return 0;
}