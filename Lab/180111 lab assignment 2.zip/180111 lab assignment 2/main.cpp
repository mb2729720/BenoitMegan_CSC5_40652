/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 10, 2018, 9:17 PM
 * Purpose:  1/11/18 Lab Assignment 2
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float milBdgt = 639.1e09f,fedBdgt = 4.094e12f, mlPrcnt = milBdgt/fedBdgt; //military budget is 639.1 billion, federal budget is 4.094 trillion, military percentage of federal budget is military/federal
    cout<<"The military budget is "<<mlPrcnt<<"% of the total federal budget.";
    return 0;
}