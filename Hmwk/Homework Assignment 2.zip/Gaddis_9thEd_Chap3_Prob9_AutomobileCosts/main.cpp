/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that calculates a user's monthly and annual
 * automobile expenses including loan payment, insurance, gas, oil, tires, and 
 * maintenance.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float loan, insurance, gas, oil, tires, maintenance;
    float monthlyTotal, annualTotal;
    
    cout<<"Monthly loan payment: ";
    cin>>loan;
    cout<<"Monthly insurance: ";
    cin>>insurance;
    cout<<"Monthly gas expenses: ";
    cin>>gas;
    cout<<"Monthly oil expenses: ";
    cin>>oil;
    cout<<"Monthly tire expenses: ";
    cin>>tires;
    cout<<"Monthly maintenance expenses: ";
    cin>>maintenance;
    
    monthlyTotal = loan+insurance+gas+oil+tires+maintenance;
    annualTotal = monthlyTotal*12;
    
    cout<<setprecision(2)<<fixed;
    cout<<"Total monthly expenses: $"<<monthlyTotal<<endl;
    cout<<"Total annual expenses: $"<<annualTotal<<endl;
            
            
    return 0;
}