/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that will convert US dollars amounts to Japanese 
 * yen and to euros.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float yenPerDollar = 83.14, eurosPerDollar = 0.7337; //conversion rates
    float dollars, yen, euros;
    
    cout<<"Dollar amount: ";
    cin>>dollars;
    
    yen = dollars*yenPerDollar;
    euros = dollars*eurosPerDollar;
    
    cout<<dollars<<" dollars is "<<yen<<" yen"<<endl;
    cout<<dollars<<" dollars is "<<euros<<" euros"<<endl;
            
    
    return 0;
}