/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 2, 2018, 2:10 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double score1, score2, score3, score4, score5;
    cout<<"Enter Score 1: "; //have user enter each score
    cin>>score1;
    cout<<"Enter Score 2: ";
    cin>>score2;
    cout<<"Enter Score 3: ";
    cin>>score3;
    cout<<"Enter Score 4: ";
    cin>>score4;
    cout<<"Enter Score 5: ";
    cin>>score5;
    float totalScore = score1+score2+score3+score4+score5; //total is all of the scores added up. this will be used in computing the average score
    float avgScore = totalScore/5; //average score is total divided by amount of scores given (in this case, 5)
    cout<<setprecision(1)<<fixed; //set precision to 1 decimal place
    cout<<"The average score is: "<<avgScore<<endl; //display average score

    return 0;
}