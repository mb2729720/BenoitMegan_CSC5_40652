/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that calculates a theater's gross and net box 
 * office profit for a night.
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    string movieName;
    double adultTix, childTix, grossBox, netBox, distributor;
    
    cout<<"Movie Name: ";
    cin>>movieName;
    cout<<"Adult Tickets Sold: ";
    cin>>adultTix;
    cout<<"Child Tickets Sold: ";
    cin>>childTix;
    
    grossBox = adultTix*6+childTix*3;
    netBox = grossBox*0.2; //net box office is 20% of gross box office
    distributor = grossBox-netBox; //distributor takes the rest
    
    cout<<setprecision(2)<<fixed;
    cout<<"Gross Box Office Profit: $"<<grossBox<<endl;
    cout<<"Net Box Office Profit: $"<<netBox<<endl;    
    cout<<"Amount Paid to Distributor: $"<<distributor<<endl;
            
            
    return 0;
}