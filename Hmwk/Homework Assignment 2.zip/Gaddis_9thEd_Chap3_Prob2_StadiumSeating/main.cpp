/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 11:15 AM
 * Purpose:  Write a program that asks how many tickets for each class of seats 
 * were sold, then displays the amount of income generated from ticket sales.
 * Format your dollar amount in fixed-point notation, with two decimal places\
 * of precision, and be sure the decimal point is always displayed.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float classA, classB, classC;
    cout<<"How many class A seats were sold? "; //ask how many seats were sold for each class
    cin>>classA;
    cout<<"How many class B seats were sold? ";
    cin>>classB;
    cout<<"How many class C seats were sold? ";
    cin>>classC;
    float classAtotal = 15.00*classA, classBtotal = 12.00*classB, classCtotal = 9.00*classC; //total for each is the amount of tickets sold for each seat class times the respective price
    float totalIncome = classAtotal+classBtotal+classCtotal; //total money made is calculated by adding the money for each class
    cout<<setprecision(2)<<fixed; //set precision to 2 decimal places
    cout<<"The total income generated is $"<<totalIncome<<endl; //display total money made
    return 0;
}