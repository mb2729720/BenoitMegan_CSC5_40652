/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that calculates and displays the number of widgets
 * stacked on a pallet.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float widgetWeight = 9.2; //widgets are 9.2 pounds each
    float emptyPallet, palletWeight, numberWidgets;
    
    cout<<"How many pounds does the pallet weigh? ";
    cin>>palletWeight;
    cout<<"How many pounds does the empty pallet weigh? ";
    cin>>emptyPallet;
    
    numberWidgets = (palletWeight-emptyPallet)/widgetWeight;
    
    cout<<"There are "<<numberWidgets<<" widgets on the pallet"<<endl;
    return 0;
}