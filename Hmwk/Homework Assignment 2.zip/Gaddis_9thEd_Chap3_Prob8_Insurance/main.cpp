/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that asks the user to enter the replacement cost of a building
and then displays the minimum amount of insurance he or she should buy for the
property.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float replacementCost;
   
    cout << "Enter the replacement cost of your building: ";
    cin >> replacementCost;
    
    float minInsurance = replacementCost*0.80; //it is recommended that the minimum insurance be 80% of replacement cost
    cout<<setprecision(2)<<fixed;
    cout<<"The minimum insurance you should buy is $"<<minInsurance<<endl;
    return 0;
}