/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that converts Celsius to Fahrenheit.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float celsius, fahrenheit;
    fahrenheit = (1.8*celsius)+32; //celsius to fahrenheit conversion
    
    cout<<"Celsius temperature: ";
    cin>>celsius;
    
    cout<<celsius<<" degrees Celsius is "<<fahrenheit<<" degrees Fahrenheit."; //display conversion
            
    return 0;
}