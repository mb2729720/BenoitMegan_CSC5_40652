/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 6:16 PM
 * Purpose:  Write a program that asks the user how many cookies they ate and outputs the amount of calories consumed.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float cookies, calories;
    
    cout<<"Number of cookies eaten: ";
    cin>>cookies;
    
    calories = cookies*75; //75 calories per cookie
    cout<<calories<<" calories consumed"<<endl;
            
    return 0;
}