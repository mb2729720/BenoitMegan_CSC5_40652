/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 12, 2018, 5:53 PM
 * Purpose:  Write a program that calculates the average rainfall for 3 months
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    string month1, month2, month3; //3 months
    double rain1, rain2, rain3; //rainfall corresponding to each month
    double avgRainfall;
    
    cout<<"Enter name of month: ";
    cin>>month1;
    cout<<"Enter the rainfall in inches: ";
    cin>>rain1;
    cout<<"Enter name of month: ";
    cin>>month2;
    cout<<"Enter the rainfall in inches: ";
    cin>>rain2;
    cout<<"Enter name of month: ";
    cin>>month3;
    cout<<"Enter the rainfall in inches: ";
    cin>>rain3;
    
    float totalRain = rain1+rain2+rain3; //total rain is rain for each of the 3 months added up
    float avgRain = totalRain/3; //average is total rainfall divided by 3
    
    cout<<setprecision(2)<<fixed;
    cout<<"The average rainfall for "<<month1<<", "<<month2<<", and "<<month3<<" is "<<avgRain<<" inches."<<endl<<endl; //display average rainfall
    return 0;
}