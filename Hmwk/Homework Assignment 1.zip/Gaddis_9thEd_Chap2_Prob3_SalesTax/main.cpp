/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 5:16 PM
 * Purpose:  Write a program that will compute the total sales tax on a $95 
 * purchase. Assume the state sales tax is 4 percent and the county sales tax 
 * is 2 percent.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double subtotal = 95.00, state = 0.04, county = 0.02; //subtotal is $95, state sales tax is 4% and county sales tax is 2%
    double state_tax = state*subtotal; //state tax 4% of the subtotal
    double county_tax = county*subtotal; //county tax is 2% of the subtotal
    double total_tax = state_tax+county_tax; //total tax is state tax + county tax
    double total_due = subtotal+total_tax; //total due is the subtotal + total tax
        cout << "The total tax is: $" << total_tax << endl; //display total tax
        cout << "The total due is: $" << total_due << endl; //display total due
    return 0;
}