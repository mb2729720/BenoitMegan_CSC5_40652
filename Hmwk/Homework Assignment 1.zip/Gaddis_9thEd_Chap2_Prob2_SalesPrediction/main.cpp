/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 4:38 PM
 * Purpose:  The East Coast sales division of a company generates 58 percent of 
 * total sales. Based on that percentage, write a program that will predict how 
 * much the East Coast division will generate if the company has $8.6 million in 
 * sales this year.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double ec_division = 0.58; //East Coast Sales Division generates 58%
    double total_sales = 8600000; //total sales are 8600000
    int ec_total = ec_division*total_sales; //East Cost total sales
    
        cout << "The East Coast sales division generated a total of $" << ec_total << endl; //display East Coast total sales
    return 0;
}