/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 8:00 PM
 * Purpose:   A customer in a store is purchasing five items priced $15.95, 
 * $24.95, $6.95. $12.95, and $3.95. Assume tax is 7%.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double item1 = 15.95,item2 = 24.95, item3 = 6.95, item4 = 12.95, item5 = 3.95, tax = 0.07; //item prices $15.95, $24.95, $6.95. $12.95, and $3.95, tax 7%
    double subtotal = item1+item2+item3+item4+item5; //add prices of items for subtotal
    double total = subtotal+subtotal*tax; //total is subtotal with tax
    cout<<"Item 1: "<<item1<<endl; //display price of item 1
    cout<<"Item 2: "<<item2<<endl; //display price of item 2
    cout<<"Item 3: "<<item3<<endl; //display price of item 3
    cout<<"Item 4: "<<item4<<endl; //display price of item 4
    cout<<"Item 5: "<<item5<<endl; //display price of item 5
    cout<<"Subtotal: "<<subtotal<<endl; //display subtotal
    cout<<"Total: "<<total<<endl; //display total
    return 0;
}