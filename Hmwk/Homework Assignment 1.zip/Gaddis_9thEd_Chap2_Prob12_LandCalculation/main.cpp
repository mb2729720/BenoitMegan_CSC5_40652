/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 8, 2018, 6:58 PM
 * Purpose:  One acre of land is equivalent to 43,560 square feet. Write a 
 * program that calculates the number of acres in a tract of land with 391,876 
 * square feet.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double acre = 43560, tract = 391876;
    double tractAcres = tract/acre;
    cout<<"Acres in tract: "<<tractAcres<<endl;
    return 0;
}