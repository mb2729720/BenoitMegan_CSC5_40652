/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 7:32 PM
 * Purpose:  Assuming the ocean’s level is currently rising at about 1.5 
 * millimeters per year, write a program that displays the number of millimeters 
 * higher than the current level that the ocean’s level will be in 5,7, and 10 
 * years
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double rate = 1.5; //ocean's level rising at about 1.5mm/year
    double year5 = rate*5, year7 = rate*7, year10 = rate*10; //predict how much ocean will rise in 5, 7, 10 years
     cout << "In 5 years the ocean level will be about " << year5 << " millimeters higher" << endl; //display predictions
     cout << "In 7 years the ocean level will be about " << year7 << " millimeters higher" << endl;
     cout << "In 10 years the ocean level will be about " << year10 << " millimeters higher" << endl;
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}