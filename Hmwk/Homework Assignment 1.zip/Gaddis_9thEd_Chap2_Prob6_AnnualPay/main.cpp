/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 8, 2018, 1:20 PM
 * Purpose:  Suppose an employee gets paid every two weeks and earns $2,200 each
 * pay period. In a year the employee gets paid 26 times. The program should 
 * calculate the employee’s total annual pay by multiplying the employee’s pay
 * amount by the number of pay periods in a year and store the result in the 
 * annualPay variable. Display the total annual pay on the screen. 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    int payAmount = 2200.00, payPeriods = 26, annualPay = payAmount*payPeriods; //employee is paid $2,200
    cout<<"Annual Pay Total: $"<<annualPay; //display annual pay
    return 0;
}