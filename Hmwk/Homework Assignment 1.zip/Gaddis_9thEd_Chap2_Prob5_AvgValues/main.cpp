/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr
 * Created on January 7, 2018, 6:00 PM
 * Purpose:  To get the average of a series of values, you add the values up 
 * and then divide the sum by the number of values. Write a program that stores 
 * the following values in five different variables: 28, 32, 37, 24, and 33. 
 * The program should first calculate the sum of these five variables and store 
 * the result in a separate variable named sum. Then, the program should divide 
 * the sum variable by 5 to get the average. Display the average on the screen.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double a = 28, b = 32, c = 37, d = 24, e = 33; //declare variables
    double sum = a+b+c+d+e; //add all numbers
    double average = sum/5; //divide sum by 5
        cout<<"The average value is: "<<average<<endl; //display average
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}