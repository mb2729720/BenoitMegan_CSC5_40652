/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 8, 2018, 1:20 PM
 * Purpose:  A car with a 20 gallon gas tank averages 23.5 miles per gallon
 * when driven in town and 28.9 miles per gallon when driven on the highway. 
 * Write a program that calculates and displays the distance the car can travel 
 * on one tank of gas when driven in town and on the highway.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    double gallons = 20, MPGTown = 23.5, MPGHighway = 28.9; //tank holds 20 gallons, avg mpg in town is 23.5 mpg, avg mpg on highway is 28.9mpg
    double distTown = gallons*MPGTown, distHighway = gallons*MPGHighway;
    cout << "The car can travel an average distance of " << distTown << " miles on one tank of gas when driving in town"; //display distances
    cout << " and " << distHighway << " miles on the highway.";
    return 0;
}