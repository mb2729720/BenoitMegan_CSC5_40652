/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 8:43 PM
 * Purpose:  A car holds 15 gallons of gasoline and can travel 375 miles before
 * refueling. Write a program that calculates the number of miles per gallon the
 * car gets. Display the result on the screen.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    int miles = 375, gallons = 15; //car can go 375 miles on a tank of gas, tank holds 15 gallons
    int mpg = miles/gallons; //miles per gallon = miles/gallons
    cout<<"MPG: "<<mpg<<endl;
    return 0;
}