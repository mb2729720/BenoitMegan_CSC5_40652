/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 7, 2018, 4:07 PM
 * Purpose:  Write a program that stores the integers 50 and 100 in variables, and stores the sum of these two in a variable named total.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    int x = 50;   //Declare Variables
    int y = 100;  //Declare Variables
    
    int total = x+y; //Add variables x and y
    
    cout<<"x+y="<<total<<endl; //Display total
    return 0;
}