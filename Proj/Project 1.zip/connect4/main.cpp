/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 17, 2018, 12:53 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
#include<string>
#include <cmath>

using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    string player1, player2;
    char column;
    short A, B, C, D, E, F, G;
    int turn;
    bool p1turn;
    
    cout<<"Enter name of player 1: ";
    cin>>player1;
    cout<<"Enter name of player 2: ";
    cin>>player2;
    cin.ignore();
    cout<<endl;
    
    cout<<"- - - - - - -"<<endl; //Display blank board
    cout<<"- - - - - - -"<<endl;
    cout<<"- - - - - - -"<<endl;
    cout<<"- - - - - - -"<<endl;
    cout<<"- - - - - - -"<<endl;
    cout<<"- - - - - - -"<<endl;
    cout<<"A B C D E F G"<<endl<<endl;     
    
    A = B = C = D = E = F = G = 0; //set all column variables equal to 0
    
    for(turn=1; turn<=42; turn++)
    {
        if(turn%2==1)
        {
            p1turn=true;
        }
        else
        {
            p1turn=false;
        }
        if(p1turn==true) //if it is player 1's turn
        {
            while (cout<<player1<<"'s turn. Enter column: " && cin>>column &&
                    !(column=='A' || column=='B' || column=='C' || column=='D' ||
                    column=='E' || column=='F' || column=='G')) //while input is not a valid column
            {
                cout<<"Please enter a valid column. ";
                cin.clear(); //clear previous input
            }
        }
        else //if it is player 2's turn
        {
           while (cout<<player2<<"'s turn. Enter column: " && cin>>column &&
                    !(column=='A' || column=='B' || column=='C' || column=='D' ||
                    column=='E' || column=='F' || column=='G')) //while input is not a valid column
            {
                cout<<"Please enter a valid column. ";
                cin.clear(); //clear previous input
            }
        }
        switch(column) 
        {
            case 'A': //user chooses column A
                A==A++;
                if(A>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    A==A--;
                    cin.clear();
                }
                 break;
            case 'B': //user chooses column B
                 B==B++;
                if(B>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    B==B--;
                    cin.clear();
                }
                 break;
            case 'C': //user chooses column C
                 C==C++;
                if(C>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    C==C--;
                    cin.clear();
                }
                 break;
            case 'D': //user chooses column D
                 D==D++;
                if(D>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    D==D--;
                    cin.clear();
                }
                break;
            case 'E': //user chooses column E
                 E==E++;
                if(E>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    E==E--;
                    cin.clear();
                }
                 break;
            case 'F': //user chooses column F
                 F==F++;
                if(F>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    F==F--;
                    cin.clear();
                }
                 break;
            case 'G': //user chooses column G
                 G==G++;
                if(G>6)//if column is full
                {
                    cout<<"Column is full. Please choose a different column. ";
                    G==G--;
                    cin.clear();
                }
                 break;
        } 
    }
    return 0;
}