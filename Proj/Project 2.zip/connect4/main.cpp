/* 
 * File:   main.cpp
 * Author: Megan Benoit
 * Created on January 17, 2018, 12:53 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
#include<string>
#include <cmath>
#include <array>

using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const int COLS = 7;
const int ROWS = 6;

//Function Prototypes
void ResetBoard( char Board[][COLS], int Rows );
void ShowBoard( char Board[][COLS], int Rows );

//Execution Begins Here
int main(int argc, char** argv) {
    string player1, player2;
    char column;
    short int colCnt[COLS];
    int turn,index;
    char board[ROWS][COLS];
    bool p1turn, invalid, p1win, p2win, draw;
    
    cout<<"Enter name of player 1: ";
    cin>>player1;
    cout<<"Enter name of player 2: ";
    cin>>player2;
    cin.ignore();
    cout<<endl;
    
    cout<<player1<<"'s pieces are represented by an X"<<endl;
    cout<<player2<<"'s pieces are represented by an O"<<endl;
    
    ResetBoard(board, ROWS); //clear the board
    ShowBoard(board, ROWS); //display board
    
    //set all column variables equal to 0
    //cout<<static_cast<int>;
    for(int i = 0; i < COLS; i++ ) colCnt[i] = 0; 
    
    p1win = p2win = false;
    
    for(turn=1; turn<=42 && p1win==false && p2win==false; turn++)
    {
        if(turn%2==1)
        {
            p1turn=true;
        }
        else
        {
            p1turn=false;
        }
        if(p1turn==true) //if it is player 1's turn
        {
            cout<<player1<<"'s turn. Enter column: ";
            do 
            {
              cin>>column;
              cin.clear(); //clear previous input
              if( !(column=='A' || column=='B' || column=='C' || column=='D' ||
                    column=='E' || column=='F' || column=='G')) //while input is not a valid column
              {
                  cout<<"Please enter a valid column. ";
              }
            } 
            while(  !(column=='A' || column=='B' || column=='C' ||
                        column=='D' || column=='E' || column=='F' || column=='G') );
        }
        else //if it is player 2's turn
        {
           while (cout<<player2<<"'s turn. Enter column: " && cin>>column &&
                    !(column=='A' || column=='B' || column=='C' || column=='D' ||
                    column=='E' || column=='F' || column=='G')) //while input is not a valid column
            {
                cout<<"Please enter a valid column. ";
                cin >> column;
                cin.clear(); //clear previous input
            }
        }
        
        do {
            invalid = false;
            switch(column) 
            {
              case 'A': //user chooses column A
                  if(colCnt[0]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[0]++;
                   break;
              case 'B': //user chooses column B
                  if(colCnt[1]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[1]++;
                   break;
              case 'C': //user chooses column C
                  if(colCnt[2]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[2]++;
                   break;
              case 'D': //user chooses column D
                  if(colCnt[3]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[3]++;
                   break;
              case 'E': //user chooses column E
                  if(colCnt[4]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[4]++;
                   break;
              case 'F': //user chooses column F
                  if(colCnt[5]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[5]++;
                   break;
              case 'G': //user chooses column G
                  if(colCnt[6]>=6)//if column is full
                  {
                      cout<<"Column is full. ";
                      cin.clear();
                      invalid = true;
                  }
                  else colCnt[6]++;
                   break;
            }
            
            if( invalid ) 
            {
                do 
                {
                  cout<<"Please enter a valid column. ";
                  cin >> column;
                  cin.clear(); //clear previous input                
                } 
                while(  !(column=='A' || column=='B' || column=='C' ||
                            column=='D' || column=='E' || column=='F' ||
                            column=='G')); //while input is not a valid column
            }
        } while( invalid );
        
        //Drop marker into column.
        index = column - 'A';
        if(p1turn==true)
        {
            board[colCnt[index]-1][index] = 'X';
        }
        else
        {
            board[colCnt[index]-1][index] = 'O';
        }
        
        
        ShowBoard(board, ROWS);
        
        //check for win
        //player 1 vertical win
        if(board[colCnt[index]-1][index] == 'X' && 
                board[colCnt[index]-2][index] == 'X' && 
                board[colCnt[index]-3][index] == 'X' && 
                board[colCnt[index]-4][index] == 'X')
        {
            p1win=true;
        }
        
        //player 1 horizontal win
        int inRow = 0;
        for( int j = 0; j < COLS && inRow < 4; j++ ) 
        {
            if( board[colCnt[index]-1][j] == 'X' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p1win=true;
        }
        
        //player 1 forward diagonal win
        inRow = 0;
        int colStrt = 0;
        int rowStrt = colCnt[index]-1 + index;
        while( rowStrt > ROWS ) 
        {
            rowStrt--;
            colStrt++;
        }
        for( int i = rowStrt, j = colStrt;
             i >= 0 && j < COLS && inRow < 4; i--, j++ ) 
        {
            if( board[i][j] == 'X' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p1win=true;
        }

        //player 1 backward diagonal win
        inRow = 0;
        colStrt = COLS-1;
        rowStrt = colCnt[index]-1 + ( COLS - 1 - index);
        while( rowStrt > ROWS ) 
        {
            rowStrt--;
            colStrt--;
        }
        for( int i = rowStrt, j = colStrt;
             i >= 0 && j >= 0 && inRow < 4; i--, j-- ) 
        {
            if( board[i][j] == 'X' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p1win=true;
        }
        
        //player 2 vertical win
        if(board[colCnt[index]-1][index] == 'O' && 
                board[colCnt[index]-2][index] == 'O' && 
                board[colCnt[index]-3][index] == 'O' && 
                board[colCnt[index]-4][index] == 'O')
        {
            p2win=true;
        }
        
        //player 2 horizontal win
        inRow = 0;
        for( int j = 0; j < COLS && inRow < 4; j++ ) 
        {
            if( board[colCnt[index]-1][j] == 'O' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p2win=true;
        }
        
        //player 2 forward diagonal win
        inRow = 0;
        colStrt = 0;
        rowStrt = colCnt[index]-1 + index;
        while( rowStrt > ROWS ) 
        {
            rowStrt--;
            colStrt++;
        }
        for( int i = rowStrt, j = colStrt;
             i >= 0 && j < COLS && inRow < 4; i--, j++ ) 
        {
            if( board[i][j] == 'O' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p2win=true;
        }

        //player 2 backward diagonal win
        inRow = 0;
        colStrt = COLS-1;
        rowStrt = colCnt[index]-1 + ( COLS - 1 - index);
        while( rowStrt > ROWS ) 
        {
            rowStrt--;
            colStrt--;
        }
        for( int i = rowStrt, j = colStrt;
             i >= 0 && j >= 0 && inRow < 4; i--, j-- ) 
        {
            if( board[i][j] == 'O' )
                inRow++;
            else inRow = 0;
        }        
        if( inRow >= 4 ) 
        {
            p2win=true;
        }
        
        if(p1win==true)
        {
            cout<<player1<<" wins! ";
        }
        
        if(p2win==true)
        {
            cout<<player2<<" wins! ";
        }
        
        if(turn==42 && p1win==false && p2win==false) //if no one has won and 
        {
            draw==true;
            cout<<"Draw!";
        }
        
    }   
    return 0;
}

void ResetBoard( char Board[][COLS], int Rows ) //array passed to function
{
    for(int i = 0; i < Rows; i++) 
    {
        for( int j = 0; j < COLS; j++ )
            Board[i][j] = '-';
    }
}

void ShowBoard(char Board[][COLS], int Rows) //array passed to function
{
    for(int i = Rows-1; i >= 0; i--) 
    {
        cout << '|';
        for(int j = 0; j < COLS; j++) 
        {
            cout << ' ' << Board[i][j];
        }
        cout <<" |" << endl;
    }
    cout << "  A B C D E F G" << endl;
}